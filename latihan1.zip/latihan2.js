const form = document.querySelector('form');

form.addEventListener('submit', function(e){
    e.preventDefault();
    
    const tinggi = parseInt(document.querySelector('#tinggi').value);
    const berat = parseInt(document.querySelector('#berat').value);
    const results = document.querySelector('#results');
    
    if((tinggi === '') || (tinggi < 0) || (isNaN(tinggi))){
        results.innerHTML = "Masukkan Data Yang Sesuai";
        
    } else if (berat === '' || berat < 0 || isNaN(berat)){
        results.innerHTML = "Masukkan Data Yang Sesuai";
    } else {
    const bmi = (berat / ((tinggi*tinggi)/10000)).toFixed(2);
    results.innerHTML = `<span>${bmi}</span>`
    }
    
    
});