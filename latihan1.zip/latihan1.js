function totalnilai(){
    let nilaiuas = document.querySelector("#nilaiuas").value;
    let nilaitugas = document.querySelector("#nilaitugas").value; 
    let nilaiakhir = document.querySelector("#nilaiakhir").value;
    let hasilakhir = document.querySelector(".hasilakhir");

    let hasilnilai = (nilaiuas * (30/100)) + (nilaitugas * (40/100)) + (nilaiakhir * (30/100));

    if (hasilnilai >= 80){
        hasilakhir.innerHTML = "A"
    }
    else if (hasilnilai >= 70){
        hasilakhir.innerHTML = "B"
    }
    else if (hasilnilai >= 60){
        hasilakhir.innerHTML = "C"
    }
    else if (hasilnilai >= 40){
        hasilakhir.innerHTML = "D"
    }
    else {
        hasilakhir.innerHTML = "E Karena Lebih Kecil dari 40"
    }
    document.querySelector('.comment').innerHTML = `Nilai Huruf : <span id=comment>${nilai_huruf}</span>`;
}